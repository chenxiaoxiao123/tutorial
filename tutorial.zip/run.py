#coding=utf-8  
from scrapy import cmdline  
cmdline.execute("scrapy crawl jd2".split())